import json
import tempfile
import unittest
from pathlib import Path

from remediation.scheduled_tasks import ScheduledTaskRemediation


class TestScheduledTaskRemediation(unittest.TestCase):
    def test_disable_and_restore_task(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            tasks_path = root / "scheduled_tasks.json"
            tasks_path.write_text(
                json.dumps([
                    {
                        "name": "UpdateCheck",
                        "enabled": True,
                        "action": "powershell -NoProfile -WindowStyle Hidden -File update.ps1",
                        "state": "ready",
                    }
                ]),
                encoding="utf-8",
            )

            tasker = ScheduledTaskRemediation(tasks_path)
            before = tasker.capture_snapshot()
            self.assertEqual(len(before["before_state"]), 1)

            disabled = tasker.disable_task("UpdateCheck")
            self.assertEqual(disabled["status"], "disabled")
            self.assertFalse(tasker.load_tasks()["UpdateCheck"]["enabled"])

            restored = tasker.restore_task("UpdateCheck")
            self.assertEqual(restored["status"], "restored")
            self.assertTrue(tasker.load_tasks()["UpdateCheck"]["enabled"])

    def test_missing_task_reports_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tasks_path = Path(tmpdir) / "scheduled_tasks.json"
            tasks_path.write_text(json.dumps([]), encoding="utf-8")

            tasker = ScheduledTaskRemediation(tasks_path)
            result = tasker.disable_task("GhostTask")
            self.assertEqual(result["status"], "missing")


if __name__ == "__main__":
    unittest.main()
