import unittest

from core.rules import RuleEngine


class TestRuleEngine(unittest.TestCase):
    def test_match_process_name_rule(self):
        engine = RuleEngine()
        event = {
            "event_id": "evt-1",
            "process_name": "ollama.exe",
            "command_line": "ollama serve",
            "tags": [],
        }
        matches = engine.evaluate(event)
        self.assertTrue(any(item["rule_id"] == "WATCH-001" for item in matches))

    def test_match_command_line_rule(self):
        engine = RuleEngine()
        event = {
            "event_id": "evt-2",
            "process_name": "powershell.exe",
            "command_line": "powershell -enc Zg==",
            "tags": [],
        }
        matches = engine.evaluate(event)
        self.assertTrue(any(item["rule_id"] == "WATCH-002" for item in matches))


if __name__ == "__main__":
    unittest.main()
