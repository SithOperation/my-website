import json
import os
import tempfile
import unittest

from core.reporting import ReportBuilder


class TestReportBuilder(unittest.TestCase):
    def test_summary_counts_events_and_alerts(self):
        events = [
            {"source": "tasklist", "severity": "info", "process_name": "python.exe"},
            {"source": "tasklist", "severity": "medium", "process_name": "ollama.exe"},
            {"source": "tasklist", "severity": "medium", "process_name": "python.exe"},
        ]
        alerts = [
            {"severity": "medium"},
            {"severity": "high"},
        ]

        report = ReportBuilder(events, alerts).build_summary()
        self.assertEqual(report["event_count"], 3)
        self.assertEqual(report["alert_count"], 2)
        self.assertEqual(report["top_processes"]["python.exe"], 2)

    def test_normal_events_do_not_affect_threat_score(self):
        events = [{"event_type": "process_started", "severity": "medium"} for _ in range(1000)]
        result = ReportBuilder(events, []).build_threat_score()
        self.assertEqual(0, result["score"])
        self.assertEqual("LOW", result["level"])

    def test_render_text_contains_summary_header(self):
        report = ReportBuilder(
            [{"source": "tasklist", "severity": "info", "process_name": "python.exe"}],
            [{"severity": "medium"}],
        )
        text = report.render_text()
        self.assertIn("Process Monitoring Summary", text)
        self.assertIn("Events: 1", text)

    def test_health_summary_reports_operational_status(self):
        health = [
            {"component": "relay", "status": "healthy", "details": "Service running normally"},
            {"component": "db", "status": "warning", "details": "Retention pruning recent"},
        ]
        report = ReportBuilder(
            [{"source": "tasklist", "severity": "medium", "process_name": "python.exe"}],
            [{"severity": "high"}],
            health,
        )
        summary = report.build_health_summary()
        self.assertEqual(summary["overall_status"], "warning")
        self.assertEqual(summary["component_status"]["relay"], "healthy")
        self.assertIn("Operational Status", report.render_health_summary())

    def test_status_snapshot_includes_counts_and_health(self):
        health = [
            {"component": "relay", "status": "healthy", "details": "Service running normally"},
            {"component": "db", "status": "warning", "details": "Retention pruning recent"},
        ]
        report = ReportBuilder(
            [{"source": "tasklist", "severity": "medium", "process_name": "python.exe"}],
            [{"severity": "high"}],
            health,
        )
        snapshot = report.build_status_snapshot()
        self.assertEqual(snapshot["event_count"], 1)
        self.assertEqual(snapshot["alert_count"], 1)
        self.assertEqual(snapshot["overall_status"], "warning")
        self.assertIn("relay", snapshot["component_status"])

    def test_status_snapshot_can_write_json_file(self):
        health = [{"component": "relay", "status": "healthy", "details": "Service running normally"}]
        report = ReportBuilder(
            [{"source": "tasklist", "severity": "info", "process_name": "python.exe"}],
            [{"severity": "low"}],
            health,
        )

        with tempfile.TemporaryDirectory() as tmpdir:
            out_path = os.path.join(tmpdir, "status.json")
            saved = report.write_status_snapshot(out_path)
            self.assertTrue(os.path.exists(saved))
            with open(saved, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            self.assertEqual(payload["event_count"], 1)
            self.assertEqual(payload["overall_status"], "healthy")


if __name__ == "__main__":
    unittest.main()
