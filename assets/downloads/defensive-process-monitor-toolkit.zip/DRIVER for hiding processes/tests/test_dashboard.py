import json
import os
import tempfile
import unittest

from core.dashboard import Dashboard


class TestDashboard(unittest.TestCase):
    def test_load_jsonl_builds_summary(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            log_path = os.path.join(tmpdir, "events.jsonl")
            with open(log_path, "w", encoding="utf-8") as handle:
                handle.write(json.dumps({"event": "process_started", "source": "tasklist", "severity": "medium", "process_name": "ollama.exe"}) + "\n")
                handle.write(json.dumps({"rule_id": "WATCH-001", "severity": "high"}) + "\n")

            dashboard = Dashboard()
            dashboard.load_jsonl(log_path)
            summary = dashboard.summary()
            self.assertEqual(summary["event_count"], 1)
            self.assertEqual(summary["alert_count"], 1)
            self.assertIn("Process Monitoring Summary", dashboard.render())


if __name__ == "__main__":
    unittest.main()
