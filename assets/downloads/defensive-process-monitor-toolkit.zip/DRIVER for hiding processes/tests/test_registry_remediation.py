import json
import tempfile
import unittest
from pathlib import Path

from remediation.registry import RegistryRemediation


class TestRegistryRemediation(unittest.TestCase):
    def test_set_and_restore_value(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            registry_path = root / "registry.json"
            registry_path.write_text(
                json.dumps({
                    "HKCU\\Software\\Demo": {
                        "Start": "enabled",
                    }
                }),
                encoding="utf-8",
            )

            registry = RegistryRemediation(registry_path)
            snapshot = registry.capture_snapshot()
            self.assertIn("HKCU\\Software\\Demo", snapshot["before_state"])

            updated = registry.set_value("HKCU\\Software\\Demo", "Start", "disabled")
            self.assertEqual(updated["status"], "updated")
            self.assertEqual(registry.load_registry()["HKCU\\Software\\Demo"]["Start"], "disabled")

            restored = registry.restore_value("HKCU\\Software\\Demo", "Start")
            self.assertEqual(restored["status"], "restored")
            self.assertEqual(registry.load_registry()["HKCU\\Software\\Demo"]["Start"], "enabled")

    def test_missing_value_reports_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "registry.json"
            path.write_text(json.dumps({}), encoding="utf-8")

            registry = RegistryRemediation(path)
            result = registry.restore_value("HKCU\\Software\\Example", "Start")
            self.assertEqual(result["status"], "missing")


if __name__ == "__main__":
    unittest.main()
