import json
import tempfile
import unittest
from pathlib import Path

from remediation.network import NetworkRemediation


class TestNetworkRemediation(unittest.TestCase):
    def test_restore_dns_and_proxy(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            net_path = root / "network_state.json"
            net_path.write_text(
                json.dumps({
                    "dns": ["8.8.8.8"],
                    "proxy": "http://127.0.0.1:8080",
                    "hosts": ["127.0.0.1 localhost"],
                }),
                encoding="utf-8",
            )

            network = NetworkRemediation(net_path)
            snapshot = network.capture_snapshot()
            self.assertEqual(snapshot["before_state"]["dns"][0], "8.8.8.8")

            network.set_value("proxy", "http://malware.example:9000")
            restored = network.restore_value("proxy")
            self.assertEqual(restored["status"], "restored")
            self.assertEqual(network.load_state()["proxy"], "http://127.0.0.1:8080")

    def test_missing_key_reports_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "network_state.json"
            path.write_text(json.dumps({}), encoding="utf-8")

            network = NetworkRemediation(path)
            result = network.restore_value("dns")
            self.assertEqual(result["status"], "missing")


if __name__ == "__main__":
    unittest.main()
