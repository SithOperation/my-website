import tempfile
import unittest
from pathlib import Path

from recovery.center import RecoveryCenter


class TestRecoveryCenter(unittest.TestCase):
    def test_center_lists_restore_actions_and_builds_summary(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            center = RecoveryCenter(base_path=root / "recovery")
            center.add_restore_item(
                name="Startup entry",
                item_type="startup_entry",
                path="C:/Users/Test/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/evil.lnk",
                status="backed_up",
            )
            center.add_restore_item(
                name="Browser homepage",
                item_type="browser_setting",
                path="C:/Users/Test/AppData/Local/Google/Chrome/User Data/Default/Preferences",
                status="restorable",
            )

            items = center.list_items()
            self.assertEqual(len(items), 2)
            self.assertIn("Startup entry", items[0]["name"])
            summary = center.summary()
            self.assertEqual(summary["total_items"], 2)
            self.assertEqual(summary["restorable_count"], 2)
            self.assertIn("Recovery Center", center.render_summary())


if __name__ == "__main__":
    unittest.main()
