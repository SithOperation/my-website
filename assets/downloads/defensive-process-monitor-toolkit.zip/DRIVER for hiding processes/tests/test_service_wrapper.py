import json
import os
import tempfile
import unittest

from core.service_wrapper import RelayServiceWrapper


class TestRelayServiceWrapper(unittest.TestCase):
    def test_status_reports_runtime_state(self):
        wrapper = RelayServiceWrapper()
        state = wrapper.status()
        self.assertIn("running", state)
        self.assertIn("enabled", state)
        self.assertIn("poll_interval", state)

    def test_start_and_stop_lifecycle(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = os.path.join(tmpdir, "relay.jsonl")
            wrapper = RelayServiceWrapper()
            wrapper.service.output_path = output_path
            wrapper.start()
            self.assertTrue(wrapper.thread is not None)
            wrapper.stop()
            self.assertFalse(wrapper.thread.is_alive())
            self.assertTrue(str(wrapper.service.output_path).endswith("relay.jsonl"))

    def test_string_output_path_is_normalized(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            output_path = os.path.join(tmpdir, "relay.jsonl")
            wrapper = RelayServiceWrapper()
            wrapper.service.output_path = output_path
            event = {"timestamp": "2026-01-01T00:00:00Z", "source": "relay_service", "event": "process_started", "pid": 42, "image": "python.exe"}
            wrapper.service.append_jsonl(event)
            self.assertTrue(os.path.exists(output_path))
            self.assertTrue(str(wrapper.service.output_path).endswith("relay.jsonl"))


if __name__ == "__main__":
    unittest.main()
