import unittest

from core.deployment_validation import DeploymentValidator


class TestDeploymentValidator(unittest.TestCase):
    def test_inf_uses_demand_start_configuration(self):
        validator = DeploymentValidator()
        result = validator.validate()
        self.assertTrue(result["valid"] or "INF should use demand-start service configuration for lab-safe installation" not in result["issues"])

    def test_validator_reports_missing_files(self):
        validator = DeploymentValidator(repo_root=".")
        result = validator.validate()
        self.assertIn("service_name", result)
        self.assertIn("valid", result)
        self.assertIn("issues", result)

    def test_dry_run_reports_packaging_and_scripts(self):
        validator = DeploymentValidator(repo_root=".")
        result = validator.validate()
        self.assertIn("dry_run", result)
        self.assertIn("install_script_exists", result["dry_run"])
        self.assertIn("uninstall_script_exists", result["dry_run"])
        self.assertIn("driver_package_ready", result["dry_run"])


if __name__ == "__main__":
    unittest.main()
