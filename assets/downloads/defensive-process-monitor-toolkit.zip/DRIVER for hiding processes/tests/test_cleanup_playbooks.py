import unittest

from cleanup.playbooks import CleanupPlaybook, PlaybookAction


class TestCleanupPlaybooks(unittest.TestCase):
    def test_suspicious_startup_entry_gets_backup_then_remove_plan(self):
        playbook = CleanupPlaybook()
        action = playbook.evaluate_artifact(
            artifact_type="startup_entry",
            path="C:/Users/Test/AppData/Roaming/Microsoft/Windows/Start Menu/Programs/Startup/evil.lnk",
            reason="Entry launches a suspicious process at login",
            risk_score=85,
        )

        self.assertEqual(action.action, "backup_and_remove")
        self.assertTrue(action.backup_required)
        self.assertIn("Startup", action.summary)

    def test_temp_file_is_low_risk_and_safe_to_clean(self):
        playbook = CleanupPlaybook()
        action = playbook.evaluate_artifact(
            artifact_type="temporary_file",
            path="C:/Temp/cache.tmp",
            reason="Temporary file created for a short-lived process",
            risk_score=18,
        )

        self.assertEqual(action.action, "delete")
        self.assertFalse(action.backup_required)
        self.assertIn("temporary", action.summary.lower())


if __name__ == "__main__":
    unittest.main()
