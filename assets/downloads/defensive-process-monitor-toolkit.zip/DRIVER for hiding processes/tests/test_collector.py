import unittest
import tempfile
from pathlib import Path

from core.collector import ProcessTelemetryCollector


class TestProcessTelemetryCollector(unittest.TestCase):
    def test_parse_tasklist_csv_creates_normalized_events(self):
        raw_csv = '''
"Image Name","PID","Session Name","Session#","Mem Usage"
"ollama.exe","4201","Console","1","12,345 K"
"System","4","Services","0","1,234 K"
'''

        with tempfile.TemporaryDirectory() as tmpdir:
            collector = ProcessTelemetryCollector(Path(tmpdir) / "events.db")
            events = collector.parse_tasklist_csv(raw_csv)

        self.assertEqual(len(events), 2)
        self.assertEqual(events[0].event_type, "process_snapshot")
        self.assertEqual(events[0].process_name, "ollama.exe")
        self.assertEqual(events[0].pid, 4201)
        self.assertEqual(events[1].process_name, "System")

    def test_collect_once_inserts_events_into_database(self):
        raw_csv = '''
"Image Name","PID","Session Name","Session#","Mem Usage"
"python.exe","1234","Console","1","8,900 K"
'''

        with tempfile.TemporaryDirectory() as tmpdir:
            collector = ProcessTelemetryCollector(Path(tmpdir) / "events.db")
            events = collector.collect_once(raw_csv)
            self.assertEqual(len(events), 1)
            self.assertEqual(events[0].process_name, "python.exe")
            self.assertEqual(events[0].source, "tasklist")


if __name__ == "__main__":
    unittest.main()
