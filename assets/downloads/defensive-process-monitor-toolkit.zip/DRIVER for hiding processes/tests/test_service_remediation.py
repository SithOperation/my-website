import json
import tempfile
import unittest
from pathlib import Path

from remediation.services import ServiceRemediation


class TestServiceRemediation(unittest.TestCase):
    def test_disable_and_restore_service(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            root = Path(tmpdir)
            services_path = root / "services.json"
            services_path.write_text(
                json.dumps([
                    {
                        "name": "DemoSvc",
                        "status": "running",
                        "startup_type": "automatic",
                        "binary_path": r"C:\Tools\demo.exe",
                        "enabled": True,
                    }
                ]),
                encoding="utf-8",
            )

            service = ServiceRemediation(services_path)
            snapshot = service.capture_snapshot()
            self.assertEqual(len(snapshot["before_state"]), 1)

            disabled = service.disable_service("DemoSvc")
            self.assertEqual(disabled["status"], "disabled")
            self.assertFalse(service.load_services()["DemoSvc"]["enabled"])

            restored = service.restore_service("DemoSvc")
            self.assertEqual(restored["status"], "restored")
            self.assertTrue(service.load_services()["DemoSvc"]["enabled"])

    def test_missing_service_reports_missing(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = Path(tmpdir) / "services.json"
            path.write_text(json.dumps([]), encoding="utf-8")

            service = ServiceRemediation(path)
            result = service.disable_service("GhostSvc")
            self.assertEqual(result["status"], "missing")


if __name__ == "__main__":
    unittest.main()
