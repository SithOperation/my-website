@echo off
cd /d "c:\Users\newho\GitHub_Repos\DRIVER for hiding processes"
"C:\Program Files\Microsoft Visual Studio\18\Community\MSBuild\Current\Bin\amd64\MSBuild.exe" ProcessMonitor.vcxproj /p:Configuration=Debug /p:Platform=x64
