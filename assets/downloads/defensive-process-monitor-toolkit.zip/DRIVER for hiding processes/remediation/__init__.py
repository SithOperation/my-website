from .quarantine import QuarantineVault

__all__ = ["QuarantineVault"]
