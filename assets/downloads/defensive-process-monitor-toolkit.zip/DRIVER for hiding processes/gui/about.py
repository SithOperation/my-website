from tkinter import ttk

from gui.widgets import Page


class AboutPage(Page):
    def __init__(self, parent):
        super().__init__(parent, "About", "ProcessMonitor defensive monitoring toolkit")
        text = ("Transparent Windows process visibility for authorized defensive labs.\n\n"
                "The kernel driver observes process activity. The persistent user-mode relay polls Windows, writes JSONL, "
                "and updates SQLite. This GUI provides read-only operational visibility plus explicit relay controls.\n\n"
                "No hiding, injection, security bypass, automatic persistence, or automatic remediation is implemented.")
        ttk.Label(self, text=text, wraplength=850, justify="left").grid(row=2, column=0, sticky="nw")
