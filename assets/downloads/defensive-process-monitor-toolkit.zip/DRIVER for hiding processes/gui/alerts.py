from __future__ import annotations

from gui.adapters import format_timestamp
from gui.widgets import DataTable, Page


class AlertsPage(Page):
    def __init__(self, parent):
        super().__init__(parent, "Alerts", "Stored alerts and high-risk telemetry requiring review")
        self.table = DataTable(self, [("severity", "Severity", 85), ("timestamp", "Timestamp", 150),
                                      ("process", "Process", 150), ("pid", "PID", 65), ("rule", "Rule", 100),
                                      ("reason", "Reason", 260), ("status", "Status", 90)])
        self.table.grid(row=2, column=0, sticky="nsew"); self.rowconfigure(2, weight=1)

    def refresh(self, snapshot):
        rows = []
        for item in snapshot["alerts"]:
            rows.append({"severity": item.get("severity", "info"), "timestamp": format_timestamp(item.get("timestamp")),
                         "process": item.get("process_name") or item.get("title", ""), "pid": item.get("pid") or item.get("process_id", ""),
                         "rule": item.get("rule_id", ""), "reason": item.get("description") or "Rule finding",
                         "status": item.get("status", "New")})
        self.table.set_rows(rows)
