from __future__ import annotations

from tkinter import ttk

COLORS = {
    "bg": "#030812", "panel": "#07101d", "panel_alt": "#0b1626", "border": "#263858",
    "text": "#eef5ff", "muted": "#91a6c0", "accent": "#17b9ff", "good": "#00e676",
    "warn": "#ffc400", "high": "#ff7a18", "bad": "#ff3546", "critical": "#ff1744", "sidebar": "#020711", "nav_active": "#4b060b",
}


def apply_theme(root) -> None:
    root.configure(background=COLORS["bg"])
    style = ttk.Style(root)
    if "clam" in style.theme_names():
        style.theme_use("clam")
    style.configure(".", background=COLORS["bg"], foreground=COLORS["text"], font=("Segoe UI", 10))
    style.configure("TFrame", background=COLORS["bg"])
    style.configure("Panel.TFrame", background=COLORS["panel"], relief="solid", borderwidth=1)
    style.configure("Sidebar.TFrame", background=COLORS["sidebar"])
    style.configure("TLabel", background=COLORS["bg"], foreground=COLORS["text"])
    style.configure("Panel.TLabel", background=COLORS["panel"], foreground=COLORS["text"])
    style.configure("Muted.TLabel", background=COLORS["bg"], foreground=COLORS["muted"])
    style.configure("PanelMuted.TLabel", background=COLORS["panel"], foreground=COLORS["muted"])
    style.configure("Title.TLabel", font=("Segoe UI Semibold", 20), foreground=COLORS["text"])
    style.configure("CardValue.TLabel", background=COLORS["panel"], font=("Segoe UI Semibold", 20), foreground=COLORS["text"])
    style.configure("TButton", background=COLORS["panel_alt"], foreground=COLORS["text"], padding=(12, 7), borderwidth=0)
    style.map("TButton", background=[("active", COLORS["accent"])] , foreground=[("active", "white")])
    style.configure("Nav.TButton", background=COLORS["sidebar"], foreground=COLORS["text"], anchor="w", padding=(15, 9), borderwidth=0)
    style.map("Nav.TButton", background=[("active", "#101b2a")], foreground=[("active", "white")])
    style.configure("SelectedNav.TButton", background=COLORS["nav_active"], foreground="white", anchor="w", padding=(15, 9), borderwidth=1)
    style.map("SelectedNav.TButton", background=[("active", "#710b12")])
    style.configure("Accent.TButton", background=COLORS["accent"], foreground="white")
    style.configure("Success.TButton", background="#087f45", foreground="white")
    style.configure("Danger.TButton", background="#7f2730", foreground="white")
    style.configure("TEntry", fieldbackground=COLORS["panel_alt"], foreground=COLORS["text"], insertcolor=COLORS["text"], bordercolor=COLORS["border"])
    style.configure("TCombobox", fieldbackground=COLORS["panel_alt"], foreground=COLORS["text"], arrowcolor=COLORS["text"])
    style.configure("Treeview", background=COLORS["panel"], fieldbackground=COLORS["panel"], foreground=COLORS["text"], rowheight=28, borderwidth=0)
    style.configure("Treeview.Heading", background=COLORS["panel_alt"], foreground=COLORS["text"], font=("Segoe UI Semibold", 9), padding=7)
    style.map("Treeview", background=[("selected", "#24517a")])
    style.configure("TCheckbutton", background=COLORS["bg"], foreground=COLORS["text"])
    style.configure("Panel.TCheckbutton", background=COLORS["panel"], foreground=COLORS["muted"])
