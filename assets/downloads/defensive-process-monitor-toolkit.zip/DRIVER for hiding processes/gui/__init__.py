"""Windows desktop interface for the ProcessMonitor defensive toolkit."""

