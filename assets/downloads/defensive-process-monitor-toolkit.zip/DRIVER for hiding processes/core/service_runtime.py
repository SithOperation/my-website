from __future__ import annotations

import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from core.database import EventDatabase


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


@dataclass
class TelemetryRelayService:
    """Service-oriented runtime wrapper around the telemetry relay loop."""

    config_path: Optional[str | Path] = None
    output_path: Optional[str | Path] = None
    enabled: bool = True
    poll_interval: int = 2
    heartbeat_interval: int = 30
    database: Optional[EventDatabase] = field(default=None, init=False)
    _output_path_override: bool = field(default=False, init=False, repr=False)

    def __post_init__(self):
        self.config_path = Path(self.config_path) if self.config_path is not None else Path(__file__).resolve().parent.parent / "config" / "process_monitor_config.json"
        self._output_path_override = self.output_path is not None
        self.output_path = Path(self.output_path) if self.output_path is not None else Path("C:/Logs/process_monitor_events.jsonl")
        self.database = EventDatabase()
        self._load_runtime_settings()

    def _load_runtime_settings(self) -> None:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            payload = {}

        self.enabled = bool(payload.get("Enabled", self.enabled))
        telemetry = payload.get("Telemetry", {})
        self.poll_interval = max(1, int(telemetry.get("PollIntervalSeconds", self.poll_interval)))
        self.heartbeat_interval = max(5, int(telemetry.get("HeartbeatIntervalSeconds", self.heartbeat_interval)))
        configured_path = telemetry.get("Path")
        if configured_path and not self._output_path_override:
            self.output_path = Path(configured_path)

    def append_jsonl(self, event: Dict[str, Any]) -> Dict[str, Any]:
        output_path = Path(self.output_path) if not isinstance(self.output_path, Path) else self.output_path
        self.output_path = output_path
        output_path.parent.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(event, separators=(",", ":"))
        with output_path.open("a", encoding="utf-8") as handle:
            handle.write(serialized + "\n")
        if event.get("event"):
            existing_lines = output_path.read_text(encoding="utf-8").splitlines()
            self.database.insert_event(
                {
                    "event_id": f"relay-{event.get('event')}-{len(existing_lines)}",
                    "timestamp": event.get("timestamp", utc_now_iso()),
                    "event_type": event.get("event", "relay_event"),
                    "source": event.get("source", "relay_service"),
                    "severity": event.get("severity", "info"),
                    "confidence": 0,
                    "hostname": None,
                    "user": None,
                    "pid": event.get("pid"),
                    "parent_pid": None,
                    "process_name": event.get("image") or event.get("process_name"),
                    "path": None,
                    "command_line": event.get("command_line"),
                    "sha256": None,
                    "signer": None,
                    "signed": None,
                    "risk_score": 0,
                    "tags": [],
                    "metadata": {k: v for k, v in event.items() if k not in {"event", "source", "timestamp", "severity", "pid", "image", "command_line"}},
                }
            )
        return event

    def run_cycle(self, previous: Dict[int, str], current: Dict[int, str]) -> List[Dict[str, Any]]:
        events: List[Dict[str, Any]] = []

        for pid, image in current.items():
            if pid not in previous:
                event = {
                    "timestamp": utc_now_iso(),
                    "source": "relay_service",
                    "event": "process_started",
                    "pid": pid,
                    "image": image,
                    "severity": "medium",
                    "triggered_rule": True,
                }
                self.append_jsonl(event)
                events.append(event)

        for pid, image in previous.items():
            if pid not in current:
                event = {
                    "timestamp": utc_now_iso(),
                    "source": "relay_service",
                    "event": "process_exited",
                    "pid": pid,
                    "image": image,
                    "severity": "info",
                    "triggered_rule": False,
                }
                self.append_jsonl(event)
                events.append(event)

        return events

    def close(self) -> None:
        if self.database is not None:
            self.database.close()
