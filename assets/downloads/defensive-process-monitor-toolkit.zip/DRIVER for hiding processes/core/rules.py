from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class DetectionRule:
    rule_id: str
    name: str
    description: str
    severity: str = "medium"
    enabled: bool = True
    conditions: Dict[str, Any] = field(default_factory=dict)

    def matches(self, event: Dict[str, Any]) -> bool:
        if not self.enabled:
            return False

        process_name = (event.get("process_name") or "").lower()
        command_line = (event.get("command_line") or "").lower()
        tags = {str(tag).lower() for tag in event.get("tags") or []}

        if self.conditions.get("process_name"):
            target = str(self.conditions["process_name"]).lower()
            if target in process_name:
                return True

        if self.conditions.get("command_line_keyword"):
            keyword = str(self.conditions["command_line_keyword"]).lower()
            if keyword in command_line:
                return True

        if self.conditions.get("tag"):
            tag = str(self.conditions["tag"]).lower()
            if tag in tags:
                return True

        return False


class RuleEngine:
    """Simple rule engine for evaluating normalized process events."""

    def __init__(self, config_path: Optional[str | Path] = None):
        self.config_path = Path(config_path) if config_path is not None else Path(__file__).resolve().parent.parent / "config" / "process_monitor_config.json"
        self.rules = self._load_default_rules()

    def _load_default_rules(self) -> List[DetectionRule]:
        defaults = [
            DetectionRule(
                rule_id="WATCH-001",
                name="Watchlisted process",
                description="Process matches a known watchlist entry",
                severity="medium",
                enabled=True,
                conditions={"process_name": "ollama.exe"},
            ),
            DetectionRule(
                rule_id="WATCH-002",
                name="Suspicious command line",
                description="Command line includes risky execution keywords",
                severity="high",
                enabled=True,
                conditions={"command_line_keyword": "powershell"},
            ),
            DetectionRule(
                rule_id="WATCH-003",
                name="Python shell execution",
                description="Python runtime invoked in a one-liner execution pattern",
                severity="high",
                enabled=True,
                conditions={"command_line_keyword": "python -c"},
            ),
        ]
        return defaults

    def load_from_file(self) -> List[DetectionRule]:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return self.rules

        rules = []
        for idx, name in enumerate(payload.get("AlertRules", {}).get("HighRiskKeywords", []), start=1):
            rules.append(
                DetectionRule(
                    rule_id=f"CFG-{idx:03d}",
                    name=f"Keyword rule {idx}",
                    description=f"Matches keyword in command line: {name}",
                    severity="high",
                    enabled=True,
                    conditions={"command_line_keyword": name.lower()},
                )
            )
        if rules:
            self.rules = rules
        return self.rules

    def evaluate(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        alerts: List[Dict[str, Any]] = []
        for rule in self.rules:
            if rule.matches(event):
                alerts.append(
                    {
                        "alert_id": f"{rule.rule_id}-{event.get('event_id', 'unknown')}",
                        "rule_id": rule.rule_id,
                        "title": rule.name,
                        "description": rule.description,
                        "severity": rule.severity,
                        "status": "new",
                        "event_id": event.get("event_id"),
                    }
                )
        return alerts
