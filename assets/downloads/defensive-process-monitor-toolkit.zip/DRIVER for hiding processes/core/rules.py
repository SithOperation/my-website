from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional


@dataclass
class DetectionRule:
    rule_id: str
    name: str
    description: str
    severity: str = "medium"
    enabled: bool = True
    conditions: Dict[str, Any] = field(default_factory=dict)

    def matches(self, event: Dict[str, Any]) -> bool:
        if not self.enabled:
            return False

        process_name = (event.get("process_name") or "").lower()
        command_line = (event.get("command_line") or "").lower()
        tags = {str(tag).lower() for tag in event.get("tags") or []}

        if self.conditions.get("process_name"):
            target = str(self.conditions["process_name"]).lower()
            if target in process_name:
                return True

        if self.conditions.get("command_line_keyword"):
            keyword = str(self.conditions["command_line_keyword"]).lower()
            if keyword in command_line:
                return True

        if self.conditions.get("tag"):
            tag = str(self.conditions["tag"]).lower()
            if tag in tags:
                return True

        return False


class RuleEngine:
    """Simple rule engine for evaluating normalized process events."""

    def __init__(self, config_path: Optional[str | Path] = None):
        self.config_path = Path(config_path) if config_path is not None else Path(__file__).resolve().parent.parent / "config" / "process_monitor_config.json"
        self.rules = self._load_default_rules()
        self.config = self._load_config()

    def _load_config(self) -> Dict[str, Any]:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
            return payload if isinstance(payload, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            return {}

    def classify(self, event: Dict[str, Any]) -> Dict[str, Any]:
        """Classify an observation and return an explainable finding decision."""
        process_name = str(event.get("process_name") or event.get("image") or "").strip()
        command_line = str(event.get("command_line") or "").strip()
        lowered_name = process_name.lower()
        lowered_command = command_line.lower()
        allowlist = {str(item).strip().lower() for item in self.config.get("AllowList", [])}
        watchlist = {str(item).strip().lower() for item in self.config.get("WatchList", [])}
        keywords = [str(item).strip().lower() for item in self.config.get("AlertRules", {}).get("HighRiskKeywords", []) if str(item).strip()]

        if not process_name:
            return self._decision("UNKNOWN", "Insufficient process context", "info", 0)

        matched_keyword = next((keyword for keyword in keywords if keyword in lowered_command), None)
        if matched_keyword:
            return self._decision(
                "HIGH_RISK", "High-risk command-line keyword matched", "high", 70,
                rule_id=f"CFG-HIGH-{keywords.index(matched_keyword) + 1:03d}",
                details=f"Configured keyword matched: {matched_keyword}",
            )

        if lowered_name in allowlist:
            return self._decision("TRUSTED", "Explicit allowlist match", "info", 0)

        if lowered_name in watchlist:
            return self._decision(
                "WATCHLISTED", "Configured watchlist match", "medium", 25,
                rule_id="CFG-WATCHLIST", details=f"Process is listed in WatchList: {process_name}",
            )

        return self._decision("NORMAL", "No detection rules matched", "info", 0)

    @staticmethod
    def _decision(classification: str, reason: str, severity: str, risk_score: int,
                  rule_id: Optional[str] = None, details: Optional[str] = None) -> Dict[str, Any]:
        return {
            "classification": classification,
            "classification_reason": reason,
            "severity": severity,
            "risk_score": risk_score,
            "alert": rule_id is not None,
            "rule_id": rule_id,
            "reason": details or reason,
        }

    def build_alert(self, event: Dict[str, Any], decision: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        if not decision.get("alert"):
            return None
        return {
            "alert_id": f"{decision['rule_id']}-{event.get('event_id') or uuid.uuid4().hex}",
            "timestamp": event.get("timestamp"),
            "severity": decision["severity"],
            "title": f"{decision['classification'].replace('_', ' ').title()} process finding",
            "description": decision["reason"],
            "rule_id": decision["rule_id"],
            "status": "New",
            "process_id": event.get("pid"),
            "event_id": event.get("event_id"),
            "analyst_notes": "",
            "process": event.get("process_name") or event.get("image"),
            "pid": event.get("pid"),
            "reason": decision["reason"],
            "risk_score": decision["risk_score"],
            "source": event.get("source", "relay_service"),
        }

    def _load_default_rules(self) -> List[DetectionRule]:
        defaults = [
            DetectionRule(
                rule_id="WATCH-001",
                name="Watchlisted process",
                description="Process matches a known watchlist entry",
                severity="medium",
                enabled=True,
                conditions={"process_name": "ollama.exe"},
            ),
            DetectionRule(
                rule_id="WATCH-002",
                name="Suspicious command line",
                description="Command line includes risky execution keywords",
                severity="high",
                enabled=True,
                conditions={"command_line_keyword": "powershell"},
            ),
            DetectionRule(
                rule_id="WATCH-003",
                name="Python shell execution",
                description="Python runtime invoked in a one-liner execution pattern",
                severity="high",
                enabled=True,
                conditions={"command_line_keyword": "python -c"},
            ),
        ]
        return defaults

    def load_from_file(self) -> List[DetectionRule]:
        try:
            payload = json.loads(self.config_path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return self.rules

        rules = []
        for idx, name in enumerate(payload.get("AlertRules", {}).get("HighRiskKeywords", []), start=1):
            rules.append(
                DetectionRule(
                    rule_id=f"CFG-{idx:03d}",
                    name=f"Keyword rule {idx}",
                    description=f"Matches keyword in command line: {name}",
                    severity="high",
                    enabled=True,
                    conditions={"command_line_keyword": name.lower()},
                )
            )
        if rules:
            self.rules = rules
        return self.rules

    def evaluate(self, event: Dict[str, Any]) -> List[Dict[str, Any]]:
        alerts: List[Dict[str, Any]] = []
        for rule in self.rules:
            if rule.matches(event):
                alerts.append(
                    {
                        "alert_id": f"{rule.rule_id}-{event.get('event_id', 'unknown')}",
                        "rule_id": rule.rule_id,
                        "title": rule.name,
                        "description": rule.description,
                        "severity": rule.severity,
                        "status": "new",
                        "event_id": event.get("event_id"),
                    }
                )
        return alerts
