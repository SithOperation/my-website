from __future__ import annotations

import argparse
import json
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from core.service_runtime import TelemetryRelayService


class RelayServiceWrapper:
    """A thin service wrapper with start/stop control and shutdown hooks."""

    def __init__(self, config_path: Optional[str | Path] = None):
        self.config_path = Path(config_path) if config_path is not None else Path(__file__).resolve().parent.parent / "config" / "process_monitor_config.json"
        self.service = TelemetryRelayService(config_path=self.config_path)
        self.stop_event = threading.Event()
        self.thread: Optional[threading.Thread] = None

    def _current_snapshot(self) -> Dict[int, str]:
        try:
            import csv
            import io
            import subprocess

            completed = subprocess.run(
                ["tasklist", "/FO", "CSV", "/NH"],
                capture_output=True,
                text=True,
                check=True,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            result: Dict[int, str] = {}
            for row in csv.reader(io.StringIO(completed.stdout)):
                if len(row) < 2:
                    continue
                try:
                    pid = int(str(row[1]).replace(",", "").strip())
                except ValueError:
                    continue
                result[pid] = row[0].strip()
            return result
        except Exception:
            return {}

    def start(self) -> None:
        if self.thread and self.thread.is_alive():
            return

        previous = self._current_snapshot()

        def runner() -> None:
            try:
                while not self.stop_event.is_set():
                    time.sleep(self.service.poll_interval)
                    current = self._current_snapshot()
                    self.service.run_cycle(previous, current)
                    previous.clear()
                    previous.update(current)
            finally:
                self.service.close()

        self.stop_event.clear()
        self.thread = threading.Thread(target=runner, daemon=True)
        self.thread.start()

    def stop(self) -> None:
        self.stop_event.set()
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=5)
        self.service.close()

    def status(self) -> Dict[str, Any]:
        return {
            "running": bool(self.thread and self.thread.is_alive()),
            "enabled": self.service.enabled,
            "poll_interval": self.service.poll_interval,
            "output_path": str(self.service.output_path),
        }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Process monitoring relay service wrapper")
    parser.add_argument("--config", default=None)
    parser.add_argument("--status", action="store_true")
    parser.add_argument("--start", action="store_true")
    parser.add_argument("--stop", action="store_true")
    return parser


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    wrapper = RelayServiceWrapper(config_path=args.config)

    if args.status:
        print(json.dumps(wrapper.status(), sort_keys=True))
        return 0

    if args.start:
        wrapper.start()
        print(json.dumps(wrapper.status(), sort_keys=True))
        return 0

    if args.stop:
        wrapper.stop()
        print(json.dumps(wrapper.status(), sort_keys=True))
        return 0

    parser.print_help()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)
