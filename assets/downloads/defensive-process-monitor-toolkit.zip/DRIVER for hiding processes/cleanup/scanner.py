from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Optional

from cleanup.engine import CleanupCandidate, CleanupEngine, SafetyRating


@dataclass
class CleanupScanResult:
    candidates: List[CleanupCandidate]
    scanned_paths: List[str]


class CleanupScanner:
    """High-level scanner that composes multiple cleanup candidate sources."""

    def __init__(self, roots: Optional[Iterable[str]] = None):
        self.roots = [str(Path(p)) for p in (roots or [])]

    def scan(self) -> CleanupScanResult:
        engine = CleanupEngine(self.roots)
        candidates = engine.scan_candidates()
        return CleanupScanResult(candidates=candidates, scanned_paths=list(self.roots))

    def green_only(self) -> List[CleanupCandidate]:
        return [item for item in self.scan().candidates if item.safety_rating == SafetyRating.GREEN]
