from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict


@dataclass
class PlaybookAction:
    artifact_type: str
    path: str
    action: str
    risk_score: int
    summary: str
    backup_required: bool
    metadata: Dict[str, Any]


class CleanupPlaybook:
    """Map suspicious artifacts to safe, reversible cleanup actions."""

    def evaluate_artifact(self, *, artifact_type: str, path: str, reason: str, risk_score: int) -> PlaybookAction:
        artifact_type = (artifact_type or "unknown").lower()
        risk_score = max(0, min(int(risk_score), 100))

        if artifact_type == "startup_entry":
            return PlaybookAction(
                artifact_type=artifact_type,
                path=path,
                action="backup_and_remove",
                risk_score=risk_score,
                summary=f"Startup entry flagged for review: {reason}",
                backup_required=True,
                metadata={"restore_plan": "snapshot_entry_before_removal", "requires_confirmation": True},
            )

        if artifact_type == "scheduled_task":
            return PlaybookAction(
                artifact_type=artifact_type,
                path=path,
                action="disable_then_backup",
                risk_score=risk_score,
                summary=f"Scheduled task is suspicious and should be disabled before backup: {reason}",
                backup_required=True,
                metadata={"restore_plan": "restore_task_definition", "requires_confirmation": True},
            )

        if artifact_type == "temporary_file":
            return PlaybookAction(
                artifact_type=artifact_type,
                path=path,
                action="delete",
                risk_score=risk_score,
                summary=f"Temporary file is low-risk and appropriate for deletion: {reason}",
                backup_required=False,
                metadata={"restore_plan": None, "requires_confirmation": False},
            )

        if risk_score >= 70:
            return PlaybookAction(
                artifact_type=artifact_type,
                path=path,
                action="quarantine",
                risk_score=risk_score,
                summary=f"High-risk artifact should be quarantined before review: {reason}",
                backup_required=True,
                metadata={"restore_plan": "restore_quarantined_file", "requires_confirmation": True},
            )

        return PlaybookAction(
            artifact_type=artifact_type,
            path=path,
            action="review",
            risk_score=risk_score,
            summary=f"Artifact should be reviewed manually: {reason}",
            backup_required=True,
            metadata={"restore_plan": "manual_review", "requires_confirmation": True},
        )
