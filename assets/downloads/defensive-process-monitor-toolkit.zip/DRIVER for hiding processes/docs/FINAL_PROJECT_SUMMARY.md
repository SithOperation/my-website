# Final Project Summary

## Purpose

This repository is a defensive, authorized monitoring baseline for Windows process activity. It is designed for lab, internal security testing, and controlled visibility workflows. It is not intended to hide, remove, or bypass system protections.

## What is included

- Kernel-mode process/thread observer in the driver source tree
- User-mode relay that polls tasklist output and emits structured telemetry
- Canonical event model for normalized records
- SQLite-backed persistence for events, alerts, and health status
- Rule-based alert evaluation for suspicious process and command-line behavior
- Reporting and dashboard-style summaries for local visibility
- Deployment validation to confirm package readiness and lab-safe service start settings
- Reversible Windows remediation modules for startup, scheduled tasks, services, registry, browser, network, firewall, and Defender posture
- Cleanup playbooks that classify suspicious artifacts and determine safe action paths
- Recovery center for tracking restore items and summarizing remaining recovery work
- Safe operational documentation and deployment guidance

## Current status

The project is in a stable, testable, lab-ready defensive security state. The functional areas are unified around a consistent monitoring and remediation pipeline:

1. Driver layer captures process and thread lifecycle activity
2. User-mode collector normalizes tasklist output into canonical events
3. Database stores events, alerts, and health records
4. Rule engine evaluates suspicious activity
5. Reporting surfaces event, alert, and health summaries
6. Remediation modules apply reversible, auditable changes with rollback support
7. Cleanup playbooks classify artifacts and determine the correct defensive action
8. Recovery center keeps restore actions visible and reviewable
9. Deployment validation checks package readiness and operational controls

## Operational posture

This repository follows a transparent monitoring and remediation model:

- visible by design
- audit-friendly
- suitable for controlled environments
- safe for authorized defensive use
- designed for rollback and review, not silent bypass or concealment

## Files of interest

- src/process_monitor_driver.c
- src/process_monitor_driver.h
- core/event_model.py
- core/database.py
- core/collector.py
- core/rules.py
- core/reporting.py
- core/dashboard.py
- core/service_runtime.py
- core/service_wrapper.py
- core/deployment_validation.py
- remediation/startup.py
- remediation/scheduled_tasks.py
- remediation/services.py
- remediation/registry.py
- remediation/browser.py
- remediation/network.py
- remediation/firewall.py
- remediation/defender.py
- cleanup/playbooks.py
- recovery/center.py
- config/process_monitor_config.json
- scripts/install_driver.ps1
- scripts/uninstall_driver.ps1
- README.md

## Verification

The repository includes a regression suite under tests/ and the current baseline passes successfully with the full project validation run.
