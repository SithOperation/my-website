$ErrorActionPreference = 'Stop'

$serviceName = 'ProcessMonitor'

if (Get-Service -Name $serviceName -ErrorAction SilentlyContinue) {
    Stop-Service -Name $serviceName -ErrorAction SilentlyContinue
    sc.exe delete $serviceName | Out-Null
}

$infPath = Join-Path $PSScriptRoot '..\driver\ProcessMonitor.inf'
if (Test-Path $infPath) {
    pnputil /delete-driver ProcessMonitor.inf /uninstall /force | Out-Null
}

Write-Host 'ProcessMonitor driver uninstalled.'
