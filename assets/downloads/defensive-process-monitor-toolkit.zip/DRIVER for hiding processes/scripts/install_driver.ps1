# Run from an elevated PowerShell prompt.
$ErrorActionPreference = 'Stop'

$driverPath = (Resolve-Path (Join-Path $PSScriptRoot '..\driver\ProcessMonitor.sys')).Path
$infPath = (Resolve-Path (Join-Path $PSScriptRoot '..\driver\ProcessMonitor.inf')).Path
$serviceName = 'ProcessMonitor'

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this script from an elevated PowerShell prompt.'
}

Write-Host "Staging driver package: $infPath"
pnputil.exe /add-driver $infPath /install
if ($LASTEXITCODE -ne 0) {
    throw "pnputil failed with exit code $LASTEXITCODE"
}

# The INF defines the kernel service. Do not create a duplicate Win32 service.
$service = Get-Service -Name $serviceName -ErrorAction SilentlyContinue
if ($service) {
    if ($service.Status -ne 'Running') {
        Start-Service -Name $serviceName
    }
    Write-Host 'ProcessMonitor driver service is running.'
} else {
    Write-Warning 'The package was staged, but the ProcessMonitor service is not present. In a lab, install the Root\ProcessMonitor device with an appropriate WDK/device-install workflow.'
}
