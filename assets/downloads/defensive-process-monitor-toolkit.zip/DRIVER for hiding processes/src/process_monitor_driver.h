#pragma once

#include <ntddk.h>

#define PROCESS_MONITOR_SERVICE_NAME L"ProcessMonitor"
#define PROCESS_MONITOR_ENABLED_DEFAULT 1
#define PROCESS_MONITOR_LOG_LEVEL_DEFAULT 3

#define PROCESS_MONITOR_ENABLED_VALUE L"Enabled"
#define PROCESS_MONITOR_LOGLEVEL_VALUE L"LogLevel"

typedef struct _PROCESS_MONITOR_CONFIG {
    ULONG Enabled;
    ULONG LogLevel;
} PROCESS_MONITOR_CONFIG, *PPROCESS_MONITOR_CONFIG;

extern PROCESS_MONITOR_CONFIG g_ProcessMonitorConfig;

NTSTATUS ReadProcessMonitorConfig(_In_ PUNICODE_STRING RegistryPath);
VOID DriverUnload(_In_ PDRIVER_OBJECT DriverObject);

VOID NTAPI ProcessNotifyRoutineEx(
    _Inout_ PEPROCESS Process,
    _In_ HANDLE ProcessId,
    _Inout_opt_ PPS_CREATE_NOTIFY_INFO CreateInfo
);

VOID NTAPI ThreadNotifyRoutine(
    _In_ HANDLE ProcessId,
    _In_ HANDLE ThreadId,
    _In_ BOOLEAN Create
);
